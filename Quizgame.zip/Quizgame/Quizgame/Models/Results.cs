﻿namespace Quizgame.Models
{
    public class Results
    {
        public int Score { get; set; }
    }
}
