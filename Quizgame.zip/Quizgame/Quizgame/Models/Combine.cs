﻿namespace Quizgame.Models
{
    public class Combine
    {
        //public Ques_AnsMap QuesAnsMap { get; set; }
        public QuestionShow QuestionShow { get; set; }
    }
}
