﻿namespace Quizgame.Models
{
    public class Ques_AnsMap
    {
        public int UserId { get; set; }
        public int QuestionId { get; set; }
        public int AnswerId { get; set; }
        public int ArticleId { get; set;}
    }
}
