﻿namespace Quizgame.Models
{
    public class AnswerShow
    {
        public string? Answer { get; set; }
        public int AnswerId { get; set; }
        public Boolean IsCorrect { get; set; }
    }
}
